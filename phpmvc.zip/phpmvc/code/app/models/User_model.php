<?php

class User_model
{

    private $nama = 'Hardi Nurhapi';

    public function getUser()
    {
        return $this->nama;

        
    }
}
